package org.todo.model.user;

public class UserAlreadyExistsException extends Exception {
}
