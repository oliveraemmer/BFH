package org.todo.model.user;

public class InvalidCredentialsException extends Exception {
}
