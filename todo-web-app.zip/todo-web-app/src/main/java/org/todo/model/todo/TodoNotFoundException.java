package org.todo.model.todo;

public class TodoNotFoundException extends Exception {
}
